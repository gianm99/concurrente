from datetime import time


class Entry:

    def __init__(self, id: int, time: time):
        self.id = id
        self.time = time
