package pkg249_counterultimate;

import java.util.concurrent.atomic.AtomicInteger;

/**
 *
 * @author miquelmascarooliver
 */
public class CounterUltimate implements Runnable {

    static final int THREADS = 4;
    static final int MAX_COUNT = 1000000;
    static AtomicInteger n = new AtomicInteger(0);
    int id;

    public CounterUltimate(int id) {
        this.id = id;
    }

    @Override
    public void run() {
        int fi = MAX_COUNT / THREADS;
        System.out.println("Thread " + id);
        for (int i = 0; i < fi; i++) {
            n.getAndIncrement();
        }
    }

    public static void main(String[] args) throws InterruptedException {
        Thread[] threads = new Thread[THREADS];
        int i;
        for (i = 0; i < THREADS; i++) {
            threads[i] = new Thread(new CounterUltimate(i));
            threads[i].start();
        }
        for (i = 0; i < THREADS; i++) {
            threads[i].join();
        }
        float error = (MAX_COUNT - n.intValue()) / (float) MAX_COUNT * 100;
        System.out.println("Counter value: " + n + " Expected: " + MAX_COUNT + " Error: " + error);
    }
}
